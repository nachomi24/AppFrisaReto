package com.example.navdrawer.model


data class UserLogin(
    val phone: Int, // Puede ser nulo
    val password: String
)