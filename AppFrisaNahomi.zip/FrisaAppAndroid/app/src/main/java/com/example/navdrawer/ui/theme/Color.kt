package com.example.navdrawer.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF808080)
val PurpleGrey80 = Color(0xFF808080)
val Pink80 = Color(0xFF808080)





val Purple40 = Color(0xFFE9E9E9)


val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)



val GrisClaro = Color(0xFFE9E9E9)
val BlancoGris = Color(0xFFF3F3F3)
val RojoFrisa = Color(0xFFE7182E)

var AppBarColor = Purple40