package com.example.navdrawer.model

data class UserLoginResponse (
    val token: String? ="",
    val id: String,
    val name: String,
    val lastname: String,
    val phone: Int,
    val tags: List<String>,
    val favorites: List<String>
)