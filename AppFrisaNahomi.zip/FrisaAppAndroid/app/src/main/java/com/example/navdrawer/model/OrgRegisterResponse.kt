package com.example.navdrawer.model

class OrgRegisterResponse {
    var message: String? = null
}