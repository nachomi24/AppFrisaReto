package com.example.navdrawer.model

class UserRegistrationResponse {
    val message: String? = null

}