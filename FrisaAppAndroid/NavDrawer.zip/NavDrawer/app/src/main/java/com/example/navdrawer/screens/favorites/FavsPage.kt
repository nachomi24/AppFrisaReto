package com.example.navdrawer.screens.favorites

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun FavsPage() {
    Column {
        Text(text = "Aquí se muestran los favoritos")
    }
}