package com.example.navdrawer.screens.seguridad

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun SecurityPage() {
    Column {
        Text(text = "Aviso de privacidad")
    }
}